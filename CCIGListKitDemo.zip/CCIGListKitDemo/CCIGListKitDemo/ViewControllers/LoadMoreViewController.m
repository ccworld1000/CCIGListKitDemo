//
//  LoadMoreViewController.m
//  CCIGListKitDemo
//
//  Created by dengyouhua on 2018/7/26.
//  Copyright © 2018 cc | ccworld1000@gmail.com. All rights reserved.
//

#import "LoadMoreViewController.h"
#import "LabelSectionController.h"
#import "DemoItem.h"
#import <IGListKit.h>
#import "DemoSectionController.h"

@interface LoadMoreViewController () <IGListAdapterDataSource, UIScrollViewDelegate> {
    BOOL loading;
    NSMutableArray *items;
}

@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) IGListAdapter *adapter;

@end

@implementation LoadMoreViewController

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:[UICollectionViewLayout new]];
    }
    
    return _collectionView;
}

- (void) loadingItems {
    items = [NSMutableArray array];
    for (int i = 0; i < 2 ; i++) {
//    for (int i = 0; i < 20 ; i++) {
        [items addObject: [[DemoItem alloc] initWithName:[NSString stringWithFormat:@"%@", @(i)]]];
//            [items addObject: [[DemoItem alloc] initWithName:[NSString stringWithFormat:@"%@", @(i)] controllerClass:[NSString stringWithFormat:@"CC %@", @(i)]]];
    }
    
//    items = @[
//              [[DemoItem alloc] initWithName:@"Tail Loading" controllerClass: @"LoadMoreViewController"],
//              [[DemoItem alloc] initWithName:@"Search Autocomplete" controllerClass: @"SearchViewController"],
//              [[DemoItem alloc] initWithName:@"Mixed Data" controllerClass: @"MixedDataViewController"],
//              [[DemoItem alloc] initWithName:@"Nested Adapter" controllerClass: @"NestedAdapterViewController"],
//              [[DemoItem alloc] initWithName:@"Empty View" controllerClass: @"EmptyViewController"],
//              [[DemoItem alloc] initWithName:@"Single Section Controller" controllerClass: @"SingleSectionViewController"],
//              [[DemoItem alloc] initWithName:@"Storyboard" controllerClass: @"SingleSectionViewController" controllerIdentifier: @"demo"],
//              [[DemoItem alloc] initWithName:@"Single Section Storyboard" controllerClass: @"SingleSectionStoryboardViewController" controllerIdentifier: @"singleSectionDemo"],
//              [[DemoItem alloc] initWithName:@"Working Range" controllerClass: @"WorkingRangeViewController"],
//              [[DemoItem alloc] initWithName:@"Diff Algorithm" controllerClass: @"DiffTableViewController"],
//              [[DemoItem alloc] initWithName:@"Supplementary Views" controllerClass: @"SupplementaryViewController"],
//              [[DemoItem alloc] initWithName:@"Self-sizing cells" controllerClass: @"SelfSizingCellsViewController"],
//              [[DemoItem alloc] initWithName:@"Display delegate" controllerClass: @"DisplayViewController"],
//              [[DemoItem alloc] initWithName:@"Stacked Section Controllers" controllerClass: @"StackedViewController"],
//              [[DemoItem alloc] initWithName:@"Objc Demo" controllerClass: @"ObjcDemoViewController"],
//              [[DemoItem alloc] initWithName:@"Objc Generated Model Demo" controllerClass: @"ObjcGeneratedModelDemoViewController"],
//              [[DemoItem alloc] initWithName:@"Calendar (auto diffing)" controllerClass: @"CalendarViewController"],
//              [[DemoItem alloc] initWithName:@"Dependency Injection" controllerClass: @"AnnouncingDepsViewController"],
//              [[DemoItem alloc] initWithName:@"Reorder Cells" controllerClass: @"ReorderableViewController"],
//              [[DemoItem alloc] initWithName:@"Reorder Stacked Section Controllers" controllerClass: @"ReorderableStackedViewController"]
//              ];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    
    self.collectionView.frame = self.view.bounds;
}

- (IGListAdapter *)adapter {
    if (!_adapter) {
        _adapter = [[IGListAdapter alloc] initWithUpdater:[IGListAdapterUpdater new] viewController:self];
    }
    
    return _adapter;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self loadingItems];

    [items enumerateObjectsUsingBlock:^(DemoItem * obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSLog(@"obj name : %@", obj.name);
    }];
    
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.collectionView];
    self.adapter.collectionView = self.collectionView;
    self.adapter.dataSource = self;
}

- (NSArray<id<IGListDiffable>> *)objectsForListAdapter:(IGListAdapter *)listAdapter {;
    return [items copy];
}

- (IGListSectionController *)listAdapter:(IGListAdapter *)listAdapter sectionControllerForObject:(id)object {
    return [LabelSectionController new];
}

- (UIView *)emptyViewForListAdapter:(IGListAdapter *)listAdapter {
    return nil;
}

@end
