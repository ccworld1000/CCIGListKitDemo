//
//  LabelSectionController.h
//  CCIGListKitDemo
//
//  Created by dengyouhua on 2018/7/27.
//  Copyright © 2018 cc | ccworld1000@gmail.com. All rights reserved.
//

#import "IGListSectionController.h"

@interface LabelSectionController : IGListSectionController

@end
